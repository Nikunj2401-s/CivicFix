# CivicFix

CivicFix is a frontend-only civic issue register for residents and ward-office staff in Ward 154, Bengaluru.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/civicfix run dev` — run the CivicFix frontend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- CivicFix uses local mock state and does not require a database, authentication backend, or third-party API key.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Frontend: React + Vite, plain JSX, direct Leaflet + OpenStreetMap

## Where things live

- CivicFix UI: `artifacts/civicfix/src/App.jsx`
- Mock endpoint layer: `artifacts/civicfix/src/lib/api.js`
- CivicFix visual system: `artifacts/civicfix/src/index.css`

## Architecture decisions

- CivicFix intentionally stays frontend-only for the first build; all data is local mock state persisted in browser storage.
- Leaflet maps are instantiated once per map component and only their marker layers are rebuilt when issue data changes.
- Priority scores use the fixed civic rule `severity × 10 + resident backing`.

## Product

CivicFix lets residents browse ward issues on a map, filter and back reports, file new issues with location and photo evidence, avoid duplicate reports within 50 metres, and track progress. Ward staff can triage the same register with priority sorting, filters, photos, and inline status updates.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
