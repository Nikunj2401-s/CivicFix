import { useEffect, useMemo, useRef, useState } from "react";
import { Link, Route, Switch, useLocation } from "wouter";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import {
  Activity, AlertTriangle, ArrowDownUp, ArrowRight, Bell, Check, CircleHelp, ClipboardList,
  CloudUpload, FilePlus2, Filter, Flag, Gauge, Lightbulb, ListFilter, LocateFixed,
  LockKeyhole, Map as MapIcon, Menu, Navigation, Plus, Search, ShieldCheck,
  SlidersHorizontal, ThumbsUp, X,
} from "lucide-react";
import {
  backIssue, createIssue, findNearbyIssues, getCurrentUser, getIssues, getMyReports,
  distanceInMeters, register, signIn, updateIssueStatus, upvoteIssue,
} from "./lib/api";

const CATEGORY_LABELS = {
  pothole: "Pothole",
  garbage: "Garbage",
  water_leakage: "Water leakage",
  broken_streetlight: "Broken streetlight",
  road_damage: "Road damage",
};
const CATEGORY_ICONS = {
  pothole: AlertTriangle,
  garbage: ClipboardList,
  water_leakage: Activity,
  broken_streetlight: Lightbulb,
  road_damage: Navigation,
};
const STATUS_LABELS = { pending: "Pending review", in_progress: "In progress", resolved: "Resolved" };

function scoreBand(score) {
  if (score >= 65) return "red";
  if (score >= 40) return "amber";
  return "grey";
}

function formatDate(date) {
  return new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short", year: "numeric" }).format(new Date(date));
}

function formatShortDate(date) {
  return new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short" }).format(new Date(date));
}

function locationLabel(issue) {
  const locations = {
    "CF-1048": "Infantry Road bus stop",
    "CF-1047": "Russell Market lane",
    "CF-1043": "Cubbon Park East gate",
    "CF-1039": "Queen’s Road crossing",
    "CF-1034": "Community Hall, 2nd Cross",
    "CF-1028": "Market Street entrance",
    "CF-1021": "4th Cross, ward park",
  };
  return locations[issue.id] || `${issue.latitude.toFixed(4)}, ${issue.longitude.toFixed(4)}`;
}

function useToast() {
  const [toast, setToast] = useState("");
  useEffect(() => {
    if (!toast) return undefined;
    const timeout = window.setTimeout(() => setToast(""), 2800);
    return () => window.clearTimeout(timeout);
  }, [toast]);
  return [toast, setToast];
}

function useIssueFeed(myOnly = false) {
  const [issues, setIssues] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const refresh = async () => {
    setIsLoading(true);
    setError("");
    try {
      setIssues(myOnly ? await getMyReports() : await getIssues());
    } catch {
      setError("The local issue register could not be read.");
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => { refresh(); }, [myOnly]);
  return { issues, isLoading, error, refresh };
}

function Logo() {
  return (
    <div className="brand" data-testid="brand-civicfix">
      <div className="brand-mark">C</div>
      <div className="brand-name">CivicFix<small>WARD ACTION REGISTER</small></div>
    </div>
  );
}

function NavItem({ href, icon: Icon, label, current }) {
  return (
    <Link href={href} className={`nav-link ${current === href ? "active" : ""}`} data-testid={`link-${label.toLowerCase().replaceAll(" ", "-")}`}>
      <Icon aria-hidden="true" /><span>{label}</span>
    </Link>
  );
}

function AppShell({ children, title, eyebrow = "Resident workspace" }) {
  const [location] = useLocation();
  const [user, setUser] = useState({ name: "Ananya Rao", ward: "Ward 154 · Shivajinagar" });
  useEffect(() => { getCurrentUser().then(setUser); }, []);
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <Logo />
        <div className="nav-label">Civic register</div>
        <nav className="nav-list" aria-label="Primary navigation">
          <NavItem href="/map" icon={MapIcon} label="Issue map" current={location} />
          <NavItem href="/report" icon={FilePlus2} label="Report issue" current={location} />
          <NavItem href="/my-reports" icon={ClipboardList} label="My reports" current={location} />
          <NavItem href="/admin" icon={Gauge} label="Ward office" current={location} />
          <NavItem href="/auth" icon={LockKeyhole} label="Sign out" current={location} />
        </nav>
        <div className="sidebar-spacer" />
        <div className="ward-card" data-testid="card-active-ward">
          <div className="eyebrow">Active ward</div>
          <strong>{user.ward || "Ward 154 · Shivajinagar"}</strong>
          <span>Last register sync · just now</span>
        </div>
        <div className="profile-strip" data-testid="profile-current-user">
          <div className="avatar">{(user.name || "AR").split(" ").map((part) => part[0]).join("").slice(0, 2)}</div>
          <div><strong>{user.name || "Ananya Rao"}</strong><span>Resident account</span></div>
        </div>
      </aside>
      <main className="main-column">
        <header className="topbar">
          <div style={{ display: "flex", alignItems: "center" }}>
            <button className="icon-button mobile-menu" onClick={() => {}} aria-label="Open navigation" data-testid="button-open-navigation"><Menu size={17} /></button>
            <div><div className="topbar-kicker">{eyebrow}</div><div className="topbar-title">{title}</div></div>
          </div>
          <div className="topbar-actions">
            <button className="icon-button" aria-label="View alerts" onClick={() => {}} data-testid="button-view-alerts"><Bell size={16} /></button>
            <Link href="/report" className="quiet-button" data-testid="link-quick-report"><Plus size={15} /><span>New report</span></Link>
          </div>
        </header>
        {children}
      </main>
    </div>
  );
}

function PageHeader({ eyebrow, title, description, action }) {
  return (
    <div className="page-header">
      <div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{description && <p className="subhead">{description}</p>}</div>
      {action}
    </div>
  );
}

function Score({ score, large = false }) {
  const band = scoreBand(score);
  return <div className={`score-badge band-${band}`} style={large ? { fontSize: 40 } : undefined} data-testid={`score-${score}`}><span>{score}</span><small>priority</small></div>;
}

function StatusChip({ status }) {
  return <span className={`status-chip status-${status}`} data-testid={`status-${status}`}>{STATUS_LABELS[status]}</span>;
}

function LoadingPanel({ rows = 4 }) {
  return <div className="loading-stack" data-testid="state-loading">{Array.from({ length: rows }).map((_, index) => <div className="skeleton" key={index} style={{ height: index === 0 ? 42 : 58, width: `${96 - index * 7}%` }} />)}</div>;
}

function ErrorPanel({ onRetry }) {
  return <div className="error-state" data-testid="state-error"><AlertTriangle size={24} /><strong>Register unavailable</strong><span>Something interrupted the local register.</span><button className="button button-secondary" onClick={onRetry} data-testid="button-retry">Try again</button></div>;
}

function IssueQueueCard({ issue, onSelect }) {
  const Icon = CATEGORY_ICONS[issue.category] || Flag;
  return (
    <button className="queue-card" onClick={() => onSelect(issue)} data-testid={`card-issue-${issue.id}`}>
      <div className={`queue-stripe band-${scoreBand(issue.priority_score)}`} style={{ background: "currentColor" }} />
      <div>
        <div className="queue-title"><Icon size={13} style={{ verticalAlign: "-2px", marginRight: 5 }} />{CATEGORY_LABELS[issue.category]}</div>
        <div className="queue-location">{locationLabel(issue)}</div>
        <div className="queue-meta"><StatusChip status={issue.status} /><span>{issue.upvotes} backing{issue.upvotes === 1 ? "" : "s"}</span></div>
      </div>
      <Score score={issue.priority_score} />
    </button>
  );
}

function StatusTimeline({ status }) {
  const steps = [
    ["pending", "Pending review", "Reported and visible to the ward register."],
    ["in_progress", "In progress", "The ward office has acknowledged the work."],
    ["resolved", "Resolved", "The issue has been marked fixed."],
  ];
  const currentIndex = steps.findIndex(([value]) => value === status);
  return (
    <div className="status-timeline" data-testid="timeline-issue-status">
      {steps.map(([value, label, description], index) => (
        <div className={`timeline-step ${index <= currentIndex ? "complete" : ""} ${value === status ? "current" : ""}`} key={value}>
          <div className="timeline-node">{index < currentIndex ? <Check size={11} /> : index + 1}</div>
          <div><strong>{label}</strong><p>{description}</p></div>
        </div>
      ))}
    </div>
  );
}

function IssueDetailModal({ issue, onClose, onUpvote, canBack = true }) {
  const [isBacking, setIsBacking] = useState(false);
  const [backed, setBacked] = useState(issue?.backed_by_me);
  if (!issue) return null;
  const Icon = CATEGORY_ICONS[issue.category] || Flag;
  const handleBack = async () => {
    if (backed || isBacking) return;
    setIsBacking(true);
    await onUpvote(issue.id);
    setBacked(true);
    setIsBacking(false);
  };
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal" role="dialog" aria-modal="true" aria-labelledby="issue-detail-title" data-testid="modal-issue-detail">
        <div className="modal-head">
          <div><div className="eyebrow">{issue.id} · filed {formatDate(issue.created_at)}</div><h2 id="issue-detail-title"><Icon size={19} style={{ verticalAlign: "-3px", marginRight: 7 }} />{CATEGORY_LABELS[issue.category]}</h2></div>
          <button className="close-button" onClick={onClose} aria-label="Close issue detail" data-testid="button-close-issue-detail"><X size={18} /></button>
        </div>
        <div className="modal-body">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}><StatusChip status={issue.status} /><span className="help-text">{locationLabel(issue)}</span></div>
          <div className="issue-photo" data-testid={`photo-issue-${issue.id}`}>{issue.photo_url ? <img src={issue.photo_url} alt={`Street evidence for ${issue.id}`} /> : <div><CloudUpload size={20} /><strong>No photo attached</strong><span>Residents can add a street-level photo when filing.</span></div>}</div>
          <div className="detail-score"><Score score={issue.priority_score} large /><div><div className="score-calculation"><span>{issue.severity} severity × 10</span><b>+</b><span>{issue.upvotes} resident backing</span><b>=</b><strong>{issue.priority_score}</strong></div><span>Priority is calculated from severity and resident backing. Higher scores are reviewed first by the ward office.</span></div></div>
          <p className="detail-copy">{issue.description}</p>
          <div className="detail-meta">
            <div><span>Reported by</span><strong>{issue.reporter}</strong></div>
            <div><span>Severity</span><strong>{issue.severity} / 5</strong></div>
            <div><span>Backed by</span><strong>{issue.upvotes} residents</strong></div>
          </div>
          <div className="detail-timeline"><div className="eyebrow">Status trail</div><StatusTimeline status={issue.status} /></div>
        </div>
        <div className="modal-actions">
          <button className="button button-secondary" onClick={onClose} data-testid="button-dismiss-detail">Close</button>
          {canBack && <button className="button button-amber" disabled={backed || isBacking} onClick={handleBack} data-testid={`button-back-issue-${issue.id}`}><ThumbsUp size={15} />{backed ? "Backed by you" : isBacking ? "Recording…" : "Back this issue"}</button>}
        </div>
      </section>
    </div>
  );
}

function MapCanvas({ issues, onSelect }) {
  const mapNode = useRef(null);
  const mapRef = useRef(null);
  const markerLayerRef = useRef(null);
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;
  useEffect(() => {
    if (!mapNode.current || mapRef.current) return undefined;
    const map = L.map(mapNode.current, { zoomControl: false, attributionControl: true }).setView([12.9719, 77.5945], 15);
    L.control.zoom({ position: "bottomright" }).addTo(map);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap contributors", maxZoom: 19 }).addTo(map);
    markerLayerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;
    const sizeTimer = window.setTimeout(() => { if (mapRef.current === map) map.invalidateSize(); }, 100);
    return () => { window.clearTimeout(sizeTimer); map.remove(); mapRef.current = null; };
  }, []);
  useEffect(() => {
    if (!markerLayerRef.current) return;
    markerLayerRef.current.clearLayers();
    issues.forEach((issue) => {
      const band = scoreBand(issue.priority_score);
      const color = band === "red" ? "#b7473f" : band === "amber" ? "#c98525" : "#8e9ba7";
      const marker = L.marker([issue.latitude, issue.longitude], { icon: L.divIcon({ className: "", html: `<div class="marker-pin ${issue.status === "resolved" ? "marker-resolved" : ""}" style="background:${color}"><span>${issue.priority_score}</span></div>`, iconSize: [26, 26], iconAnchor: [13, 26] }) });
      marker.on("click", () => onSelectRef.current(issue));
      marker.bindTooltip(`${CATEGORY_LABELS[issue.category]} · ${issue.priority_score}`, { direction: "top", offset: [0, -19] });
      marker.addTo(markerLayerRef.current);
    });
  }, [issues]);
  return <div className="map-wrap"><div ref={mapNode} data-testid="map-issue-map" /><div className="map-legend"><span className="legend-item"><i className="legend-dot" style={{ background: "var(--red)" }} />urgent 65+</span><span className="legend-item"><i className="legend-dot" style={{ background: "var(--amber)" }} />watch 40–64</span><span className="legend-item"><i className="legend-dot" style={{ background: "var(--grey-band)" }} />queued</span></div></div>;
}

function CategoryFilterChips({ issues, value, onChange }) {
  const options = [["all", "All"], ...Object.entries(CATEGORY_LABELS)];
  return <div className="category-chips" role="group" aria-label="Filter by issue category">{options.map(([category, label]) => <button className={`category-chip ${value === category ? "active" : ""}`} onClick={() => onChange(category)} key={category} data-testid={`button-filter-category-${category}`}><span>{label}</span><b>{category === "all" ? issues.length : issues.filter((issue) => issue.category === category).length}</b></button>)}</div>;
}

function MapPage() {
  const { issues, isLoading, error, refresh } = useIssueFeed();
  const [category, setCategory] = useState("all");
  const [status, setStatus] = useState("all");
  const [sort, setSort] = useState("priority");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [toast, setToast] = useToast();
  const filtered = useMemo(() => issues.filter((issue) => (category === "all" || issue.category === category) && (status === "all" || issue.status === status) && `${issue.description} ${issue.category} ${locationLabel(issue)}`.toLowerCase().includes(search.toLowerCase())).sort((a, b) => sort === "recent" ? new Date(b.created_at) - new Date(a.created_at) : b.priority_score - a.priority_score), [issues, category, status, sort, search]);
  const handleUpvote = async (id) => { await upvoteIssue(id); await refresh(); setToast("Your backing has been recorded."); };
  const urgentCount = issues.filter((issue) => issue.priority_score >= 65 && issue.status !== "resolved").length;
  return (
    <AppShell title="Issue map">
      <div className="page">
        <PageHeader eyebrow="Ward 154 · Bengaluru" title="See what needs fixing." description="A shared register of street-level issues. Back a report to make resident priorities visible to the ward office." action={<Link href="/report" className="button button-amber" data-testid="link-report-from-map"><FilePlus2 size={15} />Report an issue</Link>} />
        <div className="stat-grid">
          <div className="stat-card featured"><div className="stat-label">Open register</div><div className="stat-value">{issues.filter((issue) => issue.status !== "resolved").length}</div><div className="stat-meta">issues awaiting or receiving action</div></div>
          <div className="stat-card"><div className="stat-label">Urgent attention</div><div className="stat-value band-red">{urgentCount}</div><div className="stat-meta">priority score 65 and above</div></div>
          <div className="stat-card"><div className="stat-label">In progress</div><div className="stat-value">{issues.filter((issue) => issue.status === "in_progress").length}</div><div className="stat-meta">ward action is underway</div></div>
          <div className="stat-card"><div className="stat-label">Resolved this month</div><div className="stat-value band-amber">{issues.filter((issue) => issue.status === "resolved").length}</div><div className="stat-meta">closed with a status update</div></div>
        </div>
        <div className="filter-row">
          <div style={{ position: "relative", flex: 1, minWidth: 190 }}><Search size={15} style={{ position: "absolute", left: 11, top: 12, color: "var(--muted)" }} /><input className="input search-input" style={{ width: "100%", paddingLeft: 32 }} value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search the ward register" data-testid="input-search-issues" /></div>
          <select className="filter-select" value={status} onChange={(event) => setStatus(event.target.value)} data-testid="select-filter-status"><option value="all">All statuses</option>{Object.entries(STATUS_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>
          <div className="segmented"><button className={sort === "priority" ? "active" : ""} onClick={() => setSort("priority")} data-testid="button-sort-priority"><ArrowDownUp size={12} /> Priority</button><button className={sort === "recent" ? "active" : ""} onClick={() => setSort("recent")} data-testid="button-sort-recent">Recent</button></div>
        </div>
        <CategoryFilterChips issues={issues} value={category} onChange={setCategory} />
        <div className="map-layout">
          <section className="panel map-panel"><div className="panel-header"><div><h2>Live issue map</h2><p>{filtered.length} visible reports · select a pin or queue item</p></div><button className="quiet-button" onClick={() => setToast("Map is centred on Ward 154.")} data-testid="button-centre-map"><LocateFixed size={14} />Centre ward</button></div>{isLoading ? <LoadingPanel /> : error ? <ErrorPanel onRetry={refresh} /> : <MapCanvas issues={filtered} onSelect={setSelected} />}</section>
          <section className="panel"><div className="panel-header"><div><h2>Priority queue</h2><p>Ordered by score, highest first</p></div><ListFilter size={17} color="var(--muted)" /></div>{isLoading ? <LoadingPanel rows={5} /> : error ? <ErrorPanel onRetry={refresh} /> : filtered.length ? <div className="issue-queue">{filtered.map((issue) => <IssueQueueCard key={issue.id} issue={issue} onSelect={setSelected} />)}</div> : <div className="empty-state" data-testid="state-empty-map"><Filter size={27} /><strong>No matching reports</strong><p>Try clearing a filter or searching another term.</p></div>}</section>
        </div>
      </div>
      <IssueDetailModal issue={selected} onClose={() => setSelected(null)} onUpvote={handleUpvote} />
      {toast && <div className="toast" role="status" data-testid="toast-map">{toast}</div>}
    </AppShell>
  );
}

function DuplicateModal({ nearby, onClose, onSupport, onCreateNew }) {
  return (
    <div className="modal-backdrop" role="presentation">
      <section className="modal" role="dialog" aria-modal="true" data-testid="modal-duplicate-warning">
        <div className="modal-head"><div><div className="eyebrow">Before you file</div><h2>There may already be a report here.</h2></div><button className="close-button" onClick={onClose} aria-label="Close duplicate warning" data-testid="button-close-duplicate"><X size={18} /></button></div>
        <div className="modal-body"><p className="detail-copy">We found {nearby.length === 1 ? "an existing report" : `${nearby.length} existing reports`} within 50 metres. Supporting one helps the ward office see the combined need without creating a duplicate.</p><div className="duplicate-list">{nearby.map((issue) => <div className="duplicate-card" key={issue.id}><div><strong>{CATEGORY_LABELS[issue.category]} · {issue.id}</strong><span>{Math.round(issue.distance_meters ?? 0)}m away · {issue.upvotes} supporters</span><p>{issue.description}</p></div><button className="button button-secondary" onClick={() => onSupport(issue)} data-testid={`button-support-duplicate-${issue.id}`}><ThumbsUp size={13} />Back report</button></div>)}</div></div>
        <div className="modal-actions"><button className="button button-secondary" onClick={onClose} data-testid="button-cancel-report">Cancel</button><button className="button button-amber" onClick={onCreateNew} data-testid="button-create-new-anyway">Create new anyway <ArrowRight size={14} /></button></div>
      </section>
    </div>
  );
}

function ReportLocationMap({ latitude, longitude, onChange }) {
  const mapNode = useRef(null);
  const mapRef = useRef(null);
  const markerRef = useRef(null);
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;
  useEffect(() => {
    if (!mapNode.current || mapRef.current) return undefined;
    const initial = [Number(latitude), Number(longitude)];
    const map = L.map(mapNode.current, { zoomControl: true, attributionControl: true }).setView(initial, 16);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap contributors", maxZoom: 19 }).addTo(map);
    const marker = L.marker(initial, { draggable: true }).addTo(map);
    marker.bindTooltip("Drag or click to place", { direction: "top", offset: [0, -20] }).openTooltip();
    marker.on("dragend", () => {
      const point = marker.getLatLng();
      onChangeRef.current(point.lat, point.lng);
    });
    map.on("click", (event) => {
      marker.setLatLng(event.latlng);
      onChangeRef.current(event.latlng.lat, event.latlng.lng);
    });
    mapRef.current = map;
    markerRef.current = marker;
    const sizeTimer = window.setTimeout(() => { if (mapRef.current === map) map.invalidateSize(); }, 80);
    return () => { window.clearTimeout(sizeTimer); map.remove(); mapRef.current = null; markerRef.current = null; };
  }, []);
  useEffect(() => {
    if (!markerRef.current) return;
    const point = [Number(latitude), Number(longitude)];
    markerRef.current.setLatLng(point);
    mapRef.current?.panTo(point, { animate: true, duration: .25 });
  }, [latitude, longitude]);
  return <div className="report-map-wrap"><div ref={mapNode} data-testid="map-report-location" /><div className="report-map-hint"><LocateFixed size={13} />Drag the pin or click the map to place it</div></div>;
}

function ReportPage() {
  const [, setLocation] = useLocation();
  const [category, setCategory] = useState("pothole");
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState(3);
  const [latitude, setLatitude] = useState("12.9719");
  const [longitude, setLongitude] = useState("77.5945");
  const [photoName, setPhotoName] = useState("");
  const [photoPreview, setPhotoPreview] = useState("");
  const [addressQuery, setAddressQuery] = useState("");
  const [lookupMessage, setLookupMessage] = useState("");
  const [nearby, setNearby] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [toast, setToast] = useToast();
  const setCoordinates = (nextLatitude, nextLongitude) => {
    setLatitude(Number(nextLatitude).toFixed(6));
    setLongitude(Number(nextLongitude).toFixed(6));
  };
  const lookupAddress = () => {
    const query = addressQuery.trim().toLowerCase();
    const localLocations = [
      { label: "Infantry Road bus stop", latitude: 12.9719, longitude: 77.5945 },
      { label: "Russell Market lane", latitude: 12.9737, longitude: 77.5919 },
      { label: "Cubbon Park East gate", latitude: 12.9698, longitude: 77.5978 },
      { label: "Queen’s Road crossing", latitude: 12.9754, longitude: 77.5961 },
    ];
    const match = localLocations.find((item) => item.label.toLowerCase().includes(query) || query.includes(item.label.toLowerCase()));
    if (match) {
      setCoordinates(match.latitude, match.longitude);
      setLookupMessage(`Located locally: ${match.label}`);
    } else {
      setLookupMessage(query ? "No local match. Try a ward landmark such as Infantry Road." : "Enter a landmark to search the local ward index.");
    }
  };
  const submitReport = async (force = false) => {
    if (!description.trim() || submitting) return;
    setSubmitting(true);
    const location = { latitude: Number(latitude), longitude: Number(longitude) };
    if (!force) {
      const matches = await findNearbyIssues(location.latitude, location.longitude, 50);
      if (matches.length) { setNearby(matches.map((issue) => ({ ...issue, distance_meters: distanceInMeters(location, issue) }))); setSubmitting(false); return; }
    }
    await createIssue({ category, description: description.trim(), severity, latitude: location.latitude, longitude: location.longitude, photo_url: photoPreview });
    setSubmitting(false); setNearby([]); setToast("Report added to the Ward 154 register."); setDescription(""); setPhotoName(""); setPhotoPreview("");
    window.setTimeout(() => setLocation("/my-reports"), 700);
  };
  const supportAndGo = async (issue) => { await backIssue(issue.id); setNearby([]); setSubmitting(false); setToast(`You backed ${issue.id}. No duplicate was filed.`); window.setTimeout(() => setLocation("/map"), 700); };
  return (
    <AppShell title="Report an issue">
      <div className="page">
        <PageHeader eyebrow="New register entry" title="Make the problem legible." description="A clear report gives the ward office a location, a priority signal, and a reason to act." />
        <div className="report-layout">
          <section className="panel form-panel">
            <div className="eyebrow" style={{ marginBottom: 8 }}>Issue details</div>
            <h2>What needs attention?</h2>
            <p className="subhead" style={{ marginBottom: 24 }}>Keep it specific. Mention the landmark, what is unsafe, and how long it has been happening.</p>
            <div className="form-grid">
              <div className="field"><label htmlFor="issue-category">Category</label><select id="issue-category" className="filter-select" value={category} onChange={(event) => setCategory(event.target.value)} data-testid="select-report-category">{Object.entries(CATEGORY_LABELS).map(([value, label]) => <option value={value} key={value}>{label}</option>)}</select></div>
              <div className="field"><label>Severity</label><div className="range-row"><input type="range" min="1" max="5" value={severity} onChange={(event) => setSeverity(Number(event.target.value))} data-testid="input-report-severity" /><div className="severity-value" data-testid="text-report-severity">{severity}</div></div><div className="help-text">1 is inconvenient. 5 is an immediate safety concern.</div></div>
              <div className="field full"><label htmlFor="issue-description">Description</label><textarea id="issue-description" className="textarea" value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Example: A deep pothole opens across the left lane, 20m after the bus stop…" data-testid="input-report-description" /><div className="help-text">{description.length}/500 characters</div></div>
              <div className="field full"><label htmlFor="report-address-search">Find a landmark</label><div className="location-search"><input id="report-address-search" className="input" value={addressQuery} onChange={(event) => setAddressQuery(event.target.value)} placeholder="Try Infantry Road or Russell Market" data-testid="input-report-address-search" /><button type="button" className="button button-secondary" onClick={lookupAddress} data-testid="button-lookup-address"><Search size={14} />Find location</button></div><div className="help-text">{lookupMessage || "Local lookup only — no address leaves this device."}</div></div>
              <div className="field full"><ReportLocationMap latitude={latitude} longitude={longitude} onChange={setCoordinates} /></div>
              <div className="field"><label htmlFor="report-latitude">Latitude</label><input id="report-latitude" className="input" value={latitude} onChange={(event) => setLatitude(event.target.value)} data-testid="input-report-latitude" /></div>
              <div className="field"><label htmlFor="report-longitude">Longitude</label><input id="report-longitude" className="input" value={longitude} onChange={(event) => setLongitude(event.target.value)} data-testid="input-report-longitude" /></div>
              <div className="field full"><label>Photo evidence <span style={{ color: "var(--muted-2)", fontFamily: "var(--font-sans)", textTransform: "none", letterSpacing: 0 }}>(optional)</span></label><label className="upload-box" htmlFor="issue-photo">{photoPreview ? <img className="upload-preview" src={photoPreview} alt="Selected street evidence preview" /> : <CloudUpload size={20} />}<strong>{photoName || "Add a street-level photo"}</strong><span className="help-text">Stored locally for this demo</span><input id="issue-photo" type="file" accept="image/*" onChange={(event) => { const file = event.target.files?.[0]; if (!file) return; setPhotoName(file.name); const reader = new FileReader(); reader.onload = () => setPhotoPreview(typeof reader.result === "string" ? reader.result : ""); reader.readAsDataURL(file); }} data-testid="input-report-photo" /></label></div>
            </div>
            <div className="form-actions"><Link href="/map" className="button button-secondary" data-testid="link-cancel-report">Cancel</Link><button className="button button-primary" disabled={!description.trim() || submitting} onClick={() => submitReport(false)} data-testid="button-submit-report">{submitting ? "Checking nearby reports…" : "Review and file report"}<ArrowRight size={15} /></button></div>
          </section>
          <aside className="panel info-panel"><div className="eyebrow">How CivicFix works</div><h3 style={{ marginTop: 7 }}>From street view to ward action</h3><div style={{ marginTop: 20 }}><div className="process-step"><div className="step-number">01</div><div><strong>Describe the street problem</strong><p>Use a landmark and a plain-language description.</p></div></div><div className="process-step"><div className="step-number">02</div><div><strong>Check for duplicates</strong><p>We look within 50 metres before creating a new entry.</p></div></div><div className="process-step"><div className="step-number">03</div><div><strong>Track accountable action</strong><p>The ward office updates the status as work moves forward.</p></div></div></div><div className="auth-note" style={{ marginTop: 3 }}><ShieldCheck size={15} style={{ verticalAlign: "-3px", marginRight: 5 }} />Your report is visible to residents in this ward.</div></aside>
        </div>
      </div>
      {nearby.length > 0 && <DuplicateModal nearby={nearby} onClose={() => { setNearby([]); setSubmitting(false); }} onSupport={supportAndGo} onCreateNew={() => submitReport(true)} />}
      {toast && <div className="toast" role="status" data-testid="toast-report">{toast}</div>}
    </AppShell>
  );
}

function MyReportsPage() {
  const { issues, isLoading, error, refresh } = useIssueFeed(true);
  const { issues: allIssues, refresh: refreshAll } = useIssueFeed();
  const [selected, setSelected] = useState(null);
  const [toast, setToast] = useToast();
  const backedIssues = allIssues.filter((issue) => issue.backed_by_me && issue.user_id !== "usr-01");
  const handleUpvote = async (id) => { await upvoteIssue(id); await Promise.all([refresh(), refreshAll()]); setToast("Your backing has been recorded."); };
  return (
    <AppShell title="My reports">
      <div className="page">
        <PageHeader eyebrow="Resident activity" title="Your reports, in the open." description="Follow what you raised, see resident backing, and keep the ward office accountable to a visible status." action={<Link href="/report" className="button button-amber" data-testid="link-report-from-my-reports"><FilePlus2 size={15} />New report</Link>} />
        <div className="stat-grid">
          <div className="stat-card featured"><div className="stat-label">Reports filed</div><div className="stat-value">{issues.length}</div><div className="stat-meta">in the Ward 154 register</div></div>
          <div className="stat-card"><div className="stat-label">Issues backed</div><div className="stat-value">{backedIssues.length}</div><div className="stat-meta">reports you support</div></div>
          <div className="stat-card"><div className="stat-label">Receiving action</div><div className="stat-value">{issues.filter((issue) => issue.status === "in_progress").length}</div><div className="stat-meta">currently in progress</div></div>
          <div className="stat-card"><div className="stat-label">Resolved</div><div className="stat-value band-amber">{issues.filter((issue) => issue.status === "resolved").length}</div><div className="stat-meta">closed by ward office</div></div>
        </div>
        <section className="panel"><div className="panel-header"><div><h2>Filed by Ananya</h2><p>Most recent entries first</p></div><button className="quiet-button" onClick={() => { refresh(); refreshAll(); }} data-testid="button-refresh-my-reports"><Activity size={14} />Refresh</button></div>{isLoading ? <LoadingPanel rows={3} /> : error ? <ErrorPanel onRetry={refresh} /> : issues.length ? <div className="my-reports-grid" style={{ padding: 13 }}>{issues.map((issue) => <button className="report-card" key={issue.id} onClick={() => setSelected(issue)} style={{ textAlign: "left" }} data-testid={`card-my-report-${issue.id}`}><div className="report-card-head"><div><div className="eyebrow">{issue.id} · {formatShortDate(issue.created_at)}</div><h3 style={{ marginTop: 8 }}>{CATEGORY_LABELS[issue.category]}</h3></div><Score score={issue.priority_score} /></div><p>{issue.description}</p><div className="report-card-foot"><StatusChip status={issue.status} /><span>{issue.upvotes} resident backings</span></div></button>)}</div> : <div className="empty-state" data-testid="state-empty-my-reports"><FilePlus2 size={28} /><strong>No reports yet</strong><p>When you spot something that needs action, it will appear here.</p><Link href="/report" className="button button-amber" style={{ marginTop: 16 }} data-testid="link-first-report">File your first report</Link></div>}</section>
        <section className="panel" style={{ marginTop: 15 }}><div className="panel-header"><div><h2>Backed by you</h2><p>Existing reports you have supported</p></div><ThumbsUp size={16} color="var(--muted)" /></div>{backedIssues.length ? <div className="my-reports-grid" style={{ padding: 13 }}>{backedIssues.map((issue) => <button className="report-card" key={issue.id} onClick={() => setSelected(issue)} style={{ textAlign: "left" }} data-testid={`card-backed-report-${issue.id}`}><div className="report-card-head"><div><div className="eyebrow">{issue.id} · {formatShortDate(issue.created_at)}</div><h3 style={{ marginTop: 8 }}>{CATEGORY_LABELS[issue.category]}</h3></div><Score score={issue.priority_score} /></div><p>{issue.description}</p><div className="report-card-foot"><StatusChip status={issue.status} /><span>{issue.upvotes} resident backings</span></div></button>)}</div> : <div className="empty-state"><ThumbsUp size={26} /><strong>No backed reports yet</strong><p>Back a nearby issue from the map to keep it visible here.</p><Link href="/map" className="button button-secondary" style={{ marginTop: 16 }}>Browse the ward map</Link></div>}</section>
      </div>
      <IssueDetailModal issue={selected} onClose={() => setSelected(null)} onUpvote={handleUpvote} />
      {toast && <div className="toast" role="status" data-testid="toast-my-reports">{toast}</div>}
    </AppShell>
  );
}

function AdminPage() {
  const { issues, isLoading, error, refresh } = useIssueFeed();
  const [toast, setToast] = useToast();
  const [adminSearch, setAdminSearch] = useState("");
  const [adminCategory, setAdminCategory] = useState("all");
  const [adminStatus, setAdminStatus] = useState("all");
  const handleStatus = async (id, status) => { await updateIssueStatus(id, status); await refresh(); setToast(`Status updated to ${STATUS_LABELS[status].toLowerCase()}.`); };
  const counts = Object.keys(CATEGORY_LABELS).map((category) => ({ category, count: issues.filter((issue) => issue.category === category).length }));
  const maxCount = Math.max(...counts.map((item) => item.count), 1);
  const filteredIssues = useMemo(() => issues.filter((issue) => (adminCategory === "all" || issue.category === adminCategory) && (adminStatus === "all" || issue.status === adminStatus) && `${issue.id} ${issue.description} ${issue.reporter} ${locationLabel(issue)}`.toLowerCase().includes(adminSearch.toLowerCase())).sort((a, b) => b.priority_score - a.priority_score), [issues, adminCategory, adminStatus, adminSearch]);
  return (
    <AppShell title="Ward office" eyebrow="Triage console">
      <div className="page">
        <PageHeader eyebrow="Ward 154 · Shivajinagar" title="Turn reports into action." description="Triage the resident register by priority, then leave a clear status trail for the people who raised it." action={<button className="button button-secondary" onClick={refresh} data-testid="button-refresh-admin"><Activity size={15} />Refresh register</button>} />
        <div className="stat-grid">
          <div className="stat-card featured"><div className="stat-label">Open workload</div><div className="stat-value">{issues.filter((issue) => issue.status !== "resolved").length}</div><div className="stat-meta">reports needing ward attention</div></div>
          <div className="stat-card"><div className="stat-label">Pending review</div><div className="stat-value">{issues.filter((issue) => issue.status === "pending").length}</div><div className="stat-meta">new resident entries</div></div>
          <div className="stat-card"><div className="stat-label">In progress</div><div className="stat-value">{issues.filter((issue) => issue.status === "in_progress").length}</div><div className="stat-meta">with an active action</div></div>
          <div className="stat-card"><div className="stat-label">Closed</div><div className="stat-value band-amber">{issues.filter((issue) => issue.status === "resolved").length}</div><div className="stat-meta">marked resolved</div></div>
        </div>
        <div className="admin-grid">
          <section className="panel"><div className="panel-header"><div><h2>Priority triage</h2><p>Change a status to publish an accountable update.</p></div><span className="eyebrow">{filteredIssues.length} of {issues.length} records</span></div><div className="admin-filters"><div className="admin-search"><Search size={14} /><input value={adminSearch} onChange={(event) => setAdminSearch(event.target.value)} placeholder="Search ID, reporter or place" data-testid="input-admin-search" /></div><select className="filter-select" value={adminCategory} onChange={(event) => setAdminCategory(event.target.value)} data-testid="select-admin-category"><option value="all">All categories</option>{Object.entries(CATEGORY_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select><select className="filter-select" value={adminStatus} onChange={(event) => setAdminStatus(event.target.value)} data-testid="select-admin-status"><option value="all">All statuses</option>{Object.entries(STATUS_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></div>{isLoading ? <LoadingPanel rows={5} /> : error ? <ErrorPanel onRetry={refresh} /> : filteredIssues.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Photo</th><th>Issue</th><th>Priority</th><th>Filed</th><th>Status workflow</th></tr></thead><tbody>{filteredIssues.map((issue) => <tr key={issue.id}><td>{issue.photo_url ? <img className="photo-thumb" src={issue.photo_url} alt={`Evidence for ${issue.id}`} data-testid={`photo-thumb-${issue.id}`} /> : <div className="photo-thumb photo-thumb-empty" data-testid={`photo-thumb-empty-${issue.id}`}><CloudUpload size={14} /></div>}</td><td><div className="table-title">{CATEGORY_LABELS[issue.category]}</div><div className="table-sub">{issue.id} · {locationLabel(issue)}</div></td><td><Score score={issue.priority_score} /></td><td><div className="table-sub">{formatDate(issue.created_at)}</div><div className="table-sub">{issue.reporter}</div></td><td><select className="filter-select status-select" value={issue.status} onChange={(event) => handleStatus(issue.id, event.target.value)} data-testid={`select-status-${issue.id}`}><option value="pending">Pending review</option><option value="in_progress">In progress</option><option value="resolved">Resolved</option></select></td></tr>)}</tbody></table></div> : <div className="empty-state" data-testid="state-empty-admin"><Search size={26} /><strong>No matching register entries</strong><p>Adjust the search or filters to widen the triage view.</p></div>}</section>
          <aside className="panel"><div className="panel-header"><div><h2>Register shape</h2><p>Reports by category</p></div><SlidersHorizontal size={16} color="var(--muted)" /></div><div className="bar-list">{counts.map(({ category, count }) => <div className="bar-item" key={category}><span>{CATEGORY_LABELS[category]}</span><div className="bar-track"><div className="bar-fill" style={{ width: `${(count / maxCount) * 100}%` }} /></div><strong>{count}</strong></div>)}</div><div className="panel-body" style={{ borderTop: "1px solid var(--line)" }}><div className="eyebrow">Service signal</div><div className="metric-list"><div className="metric-row"><span>Average priority</span><strong>{issues.length ? Math.round(issues.reduce((sum, issue) => sum + issue.priority_score, 0) / issues.length) : 0}</strong></div><div className="metric-row"><span>Resident backing</span><strong>{issues.reduce((sum, issue) => sum + issue.upvotes, 0)}</strong></div><div className="metric-row"><span>Resolution rate</span><strong>{issues.length ? `${Math.round((issues.filter((issue) => issue.status === "resolved").length / issues.length) * 100)}%` : "0%"}</strong></div></div></div></aside>
        </div>
      </div>
      {toast && <div className="toast" role="status" data-testid="toast-admin">{toast}</div>}
    </AppShell>
  );
}

function AuthPage() {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async (event) => {
    event.preventDefault();
    if (!email || !password || (mode === "register" && !name)) { setError("Fill in the fields above to continue."); return; }
    setBusy(true); setError("");
    await (mode === "signin" ? signIn({ email, name }) : register({ email, name }));
    setBusy(false); setLocation("/map");
  };
  return (
    <div className="auth-page">
      <section className="auth-aside"><Logo /><div className="auth-kicker">Public infrastructure, made legible</div><h1>Small reports.<br /><em>Visible action.</em></h1><p className="subhead">CivicFix connects a resident’s street view to the ward office responsible for fixing it.</p><div className="auth-footer">Built for residents of Ward 154, Shivajinagar · Bengaluru</div></section>
      <section className="auth-form-side"><div className="auth-card"><div className="eyebrow">Resident access</div><h2>{mode === "signin" ? "Welcome back." : "Join the ward register."}</h2><p className="subhead">{mode === "signin" ? "Sign in to follow reports and back the issues your street needs fixed." : "Create a local account to file reports and keep a visible record of action."}</p><div className="auth-tabs"><button className={`auth-tab ${mode === "signin" ? "active" : ""}`} onClick={() => { setMode("signin"); setError(""); }} data-testid="button-auth-signin">Sign in</button><button className={`auth-tab ${mode === "register" ? "active" : ""}`} onClick={() => { setMode("register"); setError(""); }} data-testid="button-auth-register">Create account</button></div><form className="auth-form" onSubmit={submit}>{mode === "register" && <div className="field"><label htmlFor="auth-name">Full name</label><input id="auth-name" className="input" value={name} onChange={(event) => setName(event.target.value)} placeholder="Ananya Rao" data-testid="input-auth-name" /></div>}<div className="field"><label htmlFor="auth-email">Email address</label><input id="auth-email" className="input" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" data-testid="input-auth-email" /></div><div className="field"><label htmlFor="auth-password">Password</label><input id="auth-password" className="input" type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 8 characters" data-testid="input-auth-password" /></div>{error && <div className="auth-note" role="alert" data-testid="status-auth-error">{error}</div>}<button type="submit" className="button button-primary" disabled={busy} data-testid="button-submit-auth">{busy ? "Opening your register…" : mode === "signin" ? "Sign in to CivicFix" : "Create resident account"}<ArrowRight size={15} /></button></form><p className="auth-legal">By continuing, you agree that reports are visible to other residents in your ward. This demo uses local mock data only; no account details leave this device.</p></div></section>
    </div>
  );
}

function RedirectMap() {
  const [, setLocation] = useLocation();
  useEffect(() => { setLocation("/map"); }, [setLocation]);
  return <div className="loading-stack" style={{ minHeight: "100dvh" }}><div className="skeleton" style={{ width: 170, height: 28 }} /><div className="skeleton" style={{ width: "70%", height: 100 }} /></div>;
}

function NotFoundPage() {
  return <div className="empty-state" style={{ minHeight: "100dvh", display: "grid", placeItems: "center" }}><div><CircleHelp size={32} /><strong>That page is not in the register.</strong><p>Return to the issue map to continue.</p><Link href="/map" className="button button-primary" style={{ marginTop: 16 }} data-testid="link-not-found-map">Open issue map</Link></div></div>;
}

function Router() {
  return <Switch><Route path="/" component={RedirectMap} /><Route path="/auth" component={AuthPage} /><Route path="/map" component={MapPage} /><Route path="/report" component={ReportPage} /><Route path="/my-reports" component={MyReportsPage} /><Route path="/admin" component={AdminPage} /><Route component={NotFoundPage} /></Switch>;
}

export default function App() {
  return <Router />;
}